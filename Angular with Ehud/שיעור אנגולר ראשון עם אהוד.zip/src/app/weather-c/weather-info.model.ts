export class WeatherInfo {
  public city: string;
  public temperature: number;
}
