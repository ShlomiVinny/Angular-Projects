import { WeatherInfo } from './weather-info.model';

describe('WeatherInfo', () => {
  it('should create an instance', () => {
    expect(new WeatherInfo()).toBeTruthy();
  });
});
