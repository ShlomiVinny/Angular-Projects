import { CustomerInfo } from './customer-info.model';

describe('CustomerInfo', () => {
  it('should create an instance', () => {
    expect(new CustomerInfo()).toBeTruthy();
  });
});
