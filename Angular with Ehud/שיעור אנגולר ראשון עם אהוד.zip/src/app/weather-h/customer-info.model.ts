export class CustomerInfo {
  firstName: string;
  age: 50;
}
