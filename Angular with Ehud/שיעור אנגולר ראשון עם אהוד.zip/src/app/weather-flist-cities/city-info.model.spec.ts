import { CityInfo } from './city-info.model';

describe('CityInfo', () => {
  it('should create an instance', () => {
    expect(new CityInfo()).toBeTruthy();
  });
});
