export class CityInfo {
  public continent: string;
  public nation: string;
  public city: string;
}
